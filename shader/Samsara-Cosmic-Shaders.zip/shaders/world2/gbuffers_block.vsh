#version 120

#include "/lib/inception_curve.glsl"

varying vec2 texCoord;
varying vec2 lmCoord;
varying vec4 color;
varying vec3 viewPos;

void main() {
    vec4 curvedView = inceptionCurve(gl_ModelViewMatrix * gl_Vertex);
    gl_Position = gl_ProjectionMatrix * curvedView;
    texCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmCoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    color = gl_Color;
    viewPos = curvedView.xyz;
}
